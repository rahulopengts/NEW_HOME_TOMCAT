package com.openhab.core.db.dao;

public abstract class CloudAbstractDAO implements ICloudDAO {

	
}
