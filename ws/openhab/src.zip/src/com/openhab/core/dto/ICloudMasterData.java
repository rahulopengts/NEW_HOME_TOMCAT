package com.openhab.core.dto;

import java.io.Serializable;

public interface ICloudMasterData extends Serializable{

	
}
