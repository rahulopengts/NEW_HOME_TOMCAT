package com.openhab.core.event.dto;

import com.google.common.eventbus.AllowConcurrentEvents;
import com.google.common.eventbus.Subscribe;

public class UIEventObject extends EventObject {


}
