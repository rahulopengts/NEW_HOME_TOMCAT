package com.openhab.core.constant;

public interface CloudHomeAutoConstants {

	public static final boolean CLOUD_MODE	=	true;
}
