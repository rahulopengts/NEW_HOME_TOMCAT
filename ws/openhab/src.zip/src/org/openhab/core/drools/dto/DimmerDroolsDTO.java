package org.openhab.core.drools.dto;

public class DimmerDroolsDTO extends AbstractDroolsDTO {

	
}
