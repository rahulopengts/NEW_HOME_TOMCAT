package org.openhab.core.drools.event;

/**
 * @author Vladimir Kulev
 */
public class SystemStartup {
}
