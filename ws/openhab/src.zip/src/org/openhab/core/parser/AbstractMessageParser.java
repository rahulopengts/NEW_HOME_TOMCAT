package org.openhab.core.parser;

import org.openhab.core.parser.dto.InboundMessageDTO;

public abstract class AbstractMessageParser implements IMessageParser {

	@Override
	public InboundMessageDTO parseInboundSwitchItemMessage(String value) {
		// TODO Auto-generated method stub
		return null;
	}


}
