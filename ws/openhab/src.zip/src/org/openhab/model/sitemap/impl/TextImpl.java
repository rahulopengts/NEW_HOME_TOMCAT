/**
 */
package org.openhab.model.sitemap.impl;

import org.eclipse.emf.ecore.EClass;

import org.openhab.model.sitemap.SitemapPackage;
import org.openhab.model.sitemap.Text;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Text</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class TextImpl extends LinkableWidgetImpl implements Text
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected TextImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return SitemapPackage.Literals.TEXT;
  }

} //TextImpl
