/**
 */
package org.openhab.model.sitemap;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.sitemap.SitemapPackage#getSitemapModel()
 * @model
 * @generated
 */
public interface SitemapModel extends EObject
{
} // SitemapModel
