/**
 */
package org.openhab.model.sitemap;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Group</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.sitemap.SitemapPackage#getGroup()
 * @model
 * @generated
 */
public interface Group extends LinkableWidget
{
} // Group
