/**
 */
package org.openhab.model.sitemap;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Text</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.sitemap.SitemapPackage#getText()
 * @model
 * @generated
 */
public interface Text extends LinkableWidget
{
} // Text
