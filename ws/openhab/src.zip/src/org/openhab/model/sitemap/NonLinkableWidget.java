/**
 */
package org.openhab.model.sitemap;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Non Linkable Widget</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.sitemap.SitemapPackage#getNonLinkableWidget()
 * @model
 * @generated
 */
public interface NonLinkableWidget extends Widget
{
} // NonLinkableWidget
