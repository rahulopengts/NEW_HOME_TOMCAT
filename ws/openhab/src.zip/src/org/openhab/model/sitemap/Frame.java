/**
 */
package org.openhab.model.sitemap;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Frame</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.sitemap.SitemapPackage#getFrame()
 * @model
 * @generated
 */
public interface Frame extends LinkableWidget
{
} // Frame
