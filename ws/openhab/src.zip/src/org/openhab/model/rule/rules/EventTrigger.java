/**
 */
package org.openhab.model.rule.rules;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Trigger</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.rule.rules.RulesPackage#getEventTrigger()
 * @model
 * @generated
 */
public interface EventTrigger extends EObject
{
} // EventTrigger
