/**
 */
package org.openhab.model.rule.rules.impl;

import org.eclipse.emf.ecore.EClass;

import org.openhab.model.rule.rules.RulesPackage;
import org.openhab.model.rule.rules.SystemOnStartupTrigger;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>System On Startup Trigger</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class SystemOnStartupTriggerImpl extends SystemTriggerImpl implements SystemOnStartupTrigger
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SystemOnStartupTriggerImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return RulesPackage.Literals.SYSTEM_ON_STARTUP_TRIGGER;
  }

} //SystemOnStartupTriggerImpl
