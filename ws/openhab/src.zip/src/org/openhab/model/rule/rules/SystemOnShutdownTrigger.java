/**
 */
package org.openhab.model.rule.rules;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>System On Shutdown Trigger</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.rule.rules.RulesPackage#getSystemOnShutdownTrigger()
 * @model
 * @generated
 */
public interface SystemOnShutdownTrigger extends SystemTrigger
{
} // SystemOnShutdownTrigger
