/**
 */
package org.openhab.model.rule.rules;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>System Trigger</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.rule.rules.RulesPackage#getSystemTrigger()
 * @model
 * @generated
 */
public interface SystemTrigger extends EventTrigger
{
} // SystemTrigger
