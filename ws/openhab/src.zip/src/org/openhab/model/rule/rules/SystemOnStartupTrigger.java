/**
 */
package org.openhab.model.rule.rules;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>System On Startup Trigger</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.rule.rules.RulesPackage#getSystemOnStartupTrigger()
 * @model
 * @generated
 */
public interface SystemOnStartupTrigger extends SystemTrigger
{
} // SystemOnStartupTrigger
