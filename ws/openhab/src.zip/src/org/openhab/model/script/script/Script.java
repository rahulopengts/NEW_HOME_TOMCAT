/**
 */
package org.openhab.model.script.script;

import org.eclipse.xtext.xbase.XBlockExpression;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Script</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.script.script.ScriptPackage#getScript()
 * @model
 * @generated
 */
public interface Script extends XBlockExpression
{
} // Script
