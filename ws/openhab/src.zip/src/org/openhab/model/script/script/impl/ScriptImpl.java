/**
 */
package org.openhab.model.script.script.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.xtext.xbase.impl.XBlockExpressionImpl;

import org.openhab.model.script.script.Script;
import org.openhab.model.script.script.ScriptPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Script</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ScriptImpl extends XBlockExpressionImpl implements Script
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ScriptImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ScriptPackage.Literals.SCRIPT;
  }

} //ScriptImpl
