/**
 */
package org.openhab.model.persistence.persistence;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Filter Details</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.persistence.persistence.PersistencePackage#getFilterDetails()
 * @model
 * @generated
 */
public interface FilterDetails extends EObject
{
} // FilterDetails
