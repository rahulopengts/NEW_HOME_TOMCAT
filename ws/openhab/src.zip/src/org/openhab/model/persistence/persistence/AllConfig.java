/**
 */
package org.openhab.model.persistence.persistence;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>All Config</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.persistence.persistence.PersistencePackage#getAllConfig()
 * @model
 * @generated
 */
public interface AllConfig extends EObject
{
} // AllConfig
