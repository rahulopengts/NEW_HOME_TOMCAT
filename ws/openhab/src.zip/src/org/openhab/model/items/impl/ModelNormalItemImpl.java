/**
 */
package org.openhab.model.items.impl;

import org.eclipse.emf.ecore.EClass;

import org.openhab.model.items.ItemsPackage;
import org.openhab.model.items.ModelNormalItem;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Model Normal Item</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ModelNormalItemImpl extends ModelItemImpl implements ModelNormalItem
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ModelNormalItemImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return ItemsPackage.Literals.MODEL_NORMAL_ITEM;
  }

} //ModelNormalItemImpl
