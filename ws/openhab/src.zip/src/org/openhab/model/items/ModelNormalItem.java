/**
 */
package org.openhab.model.items;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model Normal Item</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openhab.model.items.ItemsPackage#getModelNormalItem()
 * @model
 * @generated
 */
public interface ModelNormalItem extends ModelItem
{
} // ModelNormalItem
