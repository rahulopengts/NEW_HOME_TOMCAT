package org.eclipse.equinox.internal.event;

public class EventComponentImpl extends EventComponent{

}
